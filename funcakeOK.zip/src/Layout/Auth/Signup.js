import React from 'react';

const Signup = () => {
    return('signup');
}

export default Signup;