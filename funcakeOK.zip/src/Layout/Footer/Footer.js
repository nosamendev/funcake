import React from 'react';
import './Footer.css';

const Footer = () => {
    return (
        <footer>
			React / Redux project
		</footer>
    );
}

export default Footer;